# T05 AI B 완료 보고

AI B는 `HANDOFF.md`와 첨부된 소스 스냅샷(`moon-board-source-607a2df`, 커밋 `607a2df046f374aaceeaa9331e17de7187ee8ca8`)만 입력으로 받았고, 이전 AI(A)와의 대화 내용이나 추가 설명은 제공받지 않았습니다.

## 1. 완료한 기능

`#illumination-chart`에 "최근 달 조명률 변화" SVG 그래프를 실제로 렌더링했습니다.

- `prepareIlluminationChartData(state)`를 데이터 원천으로 그대로 사용하되(HANDOFF 남은 문제 1·2), 같은 `record_date`가 중복으로 들어올 경우 마지막 값으로 병합해 한 점만 남기도록 보강(T05-G04 대비).
- y축은 0~100%로 고정해 0%·100% 값이 그래프 밖으로 밀려나지 않게 함(T05-G05, G06).
- 점이 1개일 때도 중앙에 표시, 점이 없을 때는 "아직 저장된 일별 기록이 없습니다" 안내로 대체하고 예외를 던지지 않음(HANDOFF 남은 문제 3, T05-G07).
- 그래프 렌더링은 `records.json`을 다시 불러오거나 재계산하지 않고, `main()`에서 이미 불러온 `state`만 읽기 전용으로 사용(HANDOFF 남은 문제 5).
- 렌더링 실패 시에도 그래프 영역만 대체 문구로 바뀌고 메인 카드·일별 기록·수신 테스트에는 영향 없음.
- 순수 데이터/마크업 생성 로직을 `app/public/shared/chart.mjs`(신규, DOM 비의존)로 분리해 Node에서 직접 단위 테스트 가능하게 구성.

## 2. T05-G01~G10 결과 (전부 재실행, 삭제·완화·기대값 변경 없음)

```
✅ T05-G01 — 기록 1개 → 1개 표시                                    PASS
✅ T05-G02 — 기록 2개 → 두 날짜 모두 표시                            PASS
✅ T05-G03 — 날짜가 뒤섞여도 날짜순 표시                             PASS
✅ T05-G04 — 같은 날짜 중복이 그래프에 중복 표시되지 않음            PASS
✅ T05-G05 — 0% 표시                                                PASS
✅ T05-G06 — 100% 표시                                              PASS
✅ T05-G07 — 빈 기록 → 기록 없음 안내, 오류 없음                    PASS
✅ T05-G08 — 그래프 추가 전후 원본 reading 불변                     PASS
✅ T05-G09 — 기존 5종 오류 fixture 결과 불변                        PASS
✅ T05-G10 — records.json 재로드 시 그래프 데이터·저장값 1:1 일치   PASS
10/10 PASS
```

재현 명령: `npm run test:t05-graph` (신규 스크립트). 기존 `npm test`(self-test + 공식 fixture 9개)도 변경 전과 동일하게 전부 통과함을 재확인함(로그는 아래 "확인 방법" 참고).

또한 브라우저(Playwright/Chromium)로 실제 화면을 렌더링해 육안 확인:
- 실제 데이터(1건, 2026-09-15/17%) — 정상 표시, 콘솔 에러 없음.
- 임시로 5일치(0%, 55%, 17%, 100%, 62%)로 바꿔 다중 포인트·꺾은선·0%/100% 경계 확인 후 **원본 `records.json`으로 복원**(원본 실제 기록 변경 없음, T05-G08/건드리지 말 것 준수).
- 임시로 빈 배열로 바꿔 빈 상태 확인 후 동일하게 원본 복원.

## 3. 변경한 파일

- `app/public/app.js` — 수정 (기존 `prepareIlluminationChartData` 함수 제거하고 `shared/chart.mjs`에서 import, `renderIlluminationChart(state)` 추가, `main()`에서 호출)
- `app/public/shared/chart.mjs` — 신규 (그래프 데이터 준비/좌표 계산/SVG 마크업 생성, 순수 함수만 포함)
- `app/public/style.css` — 수정 (그래프용 클래스 6개 추가: `.chart-svg`, `.chart-grid`, `.chart-axis-label`, `.chart-line`, `.chart-dot`, `.chart-fallback-text` 및 `#illumination-chart:not(.chart-placeholder)`)
- `scripts/t05-graph-test.mjs` — 신규 (T05-G01~G10 자동 검사, 기존 self-test.mjs/run-fixtures-check.mjs는 그대로 재사용해 호출만 함)
- `package.json` — 수정 (`test:t05-graph` 스크립트 한 줄 추가, 기존 `test` 스크립트는 변경 없음)

건드리지 않은 것(HANDOFF 섹션 7 그대로 준수): `shared/store.mjs`, `shared/usno-adapter.mjs`, `shared/synthetic.mjs`, `data/records.json`의 실제 원본 기록, 기존 T04 fixture 파일과 `scripts/self-test.mjs` / `scripts/run-fixtures-check.mjs`의 검사 내용.

## 4. 작업 시간

첨부 파일 수신부터 마지막 테스트 통과까지 컨테이너 파일 타임스탬프 기준 약 6분(작업 지시 확인 → 재현 → 구현 → 테스트 작성 → 시각 확인까지 연속 실행, 대기 없음). 공통 상한(45분) 이내.

## 5. AI 요청/호출 횟수

이번 AI B 작업 지시(사용자 메시지)는 1회였고, 그 안에서 제가 실행한 실질적 도구 호출(파일 읽기/쓰기/편집/셸 실행)은 약 38회입니다(재현 테스트, 코드 작성, 시각 확인용 브라우저 스크린샷 3회 포함).

`evidence/t05-initial-tests.json`에 적힌 공통 상한은 `ai_requests: 12`입니다. **"요청 수"를 사용자 지시 턴 수로 세면 1회로 상한 이내지만, 실행한 도구 호출 수로 세면 38회로 상한을 크게 초과합니다.** 어느 쪽으로 셀지는 카드5의 채점 기준(T05-C52/C53)에 그대로 반영해 주세요 — 임의로 유리한 쪽으로 보고하지 않기 위해 두 수치를 모두 남깁니다.

## 6. 작업 완료 시점의 소스 버전

받은 스냅샷에는 `.git` 이력이 없어(압축된 소스 스냅샷) 새 커밋 해시를 만들 수 없습니다. 대신 변경된 소스 파일 전체의 SHA-256을 남깁니다:

- 시작 버전(HANDOFF 명시): `607a2df046f374aaceeaa9331e17de7187ee8ca8`
- 완료 시점 변경 파일 묶음 해시(SHA-256): `b91a038fb8ce05cd3fb95a4e03381ed944774d64376ad4af29092124860306d3`
  (계산 대상: `app/`, `scripts/`, `package.json` 안의 `.mjs/.js/.json/.css/.html` 전체, `evidence/`·`reference/` 제외)

실제 저장소(`https://github.com/jeonjieun03/moonBoard`, `task5-ai-a` 브랜치 기준)에 이 변경분을 반영해 커밋하면 정식 40자리 커밋 해시가 생깁니다. 카드1~2에서 AI A가 남긴 시작 커밋과 이어붙이려면, 이 변경분을 같은 브랜치(또는 `task5-ai-b`)에 커밋해 주세요.

## 7. 부족했던 인수인계 정보

크게 막힌 지점은 없었습니다. `HANDOFF.md` 4번 항목의 검사 설명은 "무엇을 확인해야 하는지"는 충분했지만 "입력값 자체"는 요약돼 있어서, `evidence/t05-initial-tests.json`(저장소 안, HANDOFF가 가리키는 원 검사 정의)의 정확한 입력값(예: G03의 날짜 순서 `09-16, 09-15, 09-17`, G04의 "같은 signal_id·record_date 중복 2건")을 대조해 사용했습니다. 이 파일이 저장소 밖에 있었다면 검사 입력을 추측으로 재구성해야 했을 것이므로, 다음 인수인계부터는 고정 검사 10개의 입력·기대값 원본(JSON)을 `HANDOFF.md`가 명시적으로 가리키는 저장소 내 경로에 포함해 두는 것을 권장합니다.
