# T05 AI A 인수인계

## 1. 목표
과제 4의 기존 일별 달 조명률 기록을 읽기 전용으로 사용해 `최근 달 조명률 변화` 그래프를 추가한다.
그래프 추가 때문에 USNO API 호출, 일별 기록 저장 규칙, 수신 오류 처리, 저장된 원본 `reading` 값은 변경하지 않는다.

## 2. 현재 상태
- AI A는 그래프 UI 자리와 그래프 데이터 준비 함수까지 구현했다.
- 실제 그래프 SVG/선/점 렌더링은 아직 구현하지 않았다.
- 현재 화면의 그래프 영역에는 `그래프 준비 중…`이 표시된다.
- `prepareIlluminationChartData(state)`는 `daily_readings`에서 날짜·조명률·단위를 읽어 날짜순으로 정렬한다.
- 현재 실제 저장 기록은 2026-09-15 / 17% 1건이다.
- AI A 작업 후 소스 기준 버전: `607a2df046f374aaceeaa9331e17de7187ee8ca8`.
- AI B에는 이 커밋의 소스 스냅샷과 이 문서만 제공한다. 이후 커밋은 AI B 입력에 포함하지 않는다.

## 3. 실행 명령
프로젝트 루트에서:
1. `npm test`
2. `npm run dev`
3. 브라우저에서 `http://localhost:8080/`을 연다.

그래프 데이터는 `app/public/data/records.json`의 `daily_readings`를 사용한다.
네트워크를 이용해 그래프 데이터를 새로 가져오지 않는다.

## 4. 통과 검사
작업 시작 전에 고정한 동일한 10개:
- T05-G01: 기록 1개 → 1개 표시
- T05-G02: 기록 2개 → 두 날짜 모두 표시
- T05-G03: 날짜가 뒤섞여도 날짜순 표시
- T05-G04: 같은 날짜 중복이 그래프에 중복 표시되지 않음
- T05-G05: 0% 표시
- T05-G06: 100% 표시
- T05-G07: 빈 기록 → 기록 없음 안내, 오류 없음
- T05-G08: 그래프 추가 전후 원본 reading 불변
- T05-G09: 기존 5종 오류 fixture 결과 불변
- T05-G10: records.json 재로드 시 그래프 데이터와 저장 날짜·조명률이 1:1 일치

AI A 작업 후 `npm test` 결과:
- self-test 전체 통과
- 공식 fixture 9개 전체 통과
- 기존 T04 테스트 로직에는 변경 없음

## 5. 남은 문제
1. `#illumination-chart`에 실제 그래프를 렌더링해야 한다.
2. `prepareIlluminationChartData(state)`를 `main()`의 실제 화면 렌더링 흐름에서 호출해야 한다.
3. 기록이 0개일 때 명확한 빈 상태를 표시해야 한다.
4. 0%와 100% 경계값을 포함해 고정 검사 10개를 실행해야 한다.
5. 그래프 렌더링이 기존 일별 기록이나 오류 상태를 변경하지 않는지 확인해야 한다.

## 6. 다음 행동
`prepareIlluminationChartData(state)`를 그대로 데이터 원천으로 사용하고, 외부 라이브러리나 새 API 호출 없이 접근 가능한 SVG 기반의 단일 그래프를 완성한다.
그 뒤 T05-G01~G10을 같은 입력과 기대값으로 실행하고 결과를 기록한다.

## 7. 건드리지 말 것
- `app/public/shared/store.mjs`의 저장/상태 전이 로직
- `app/public/shared/usno-adapter.mjs`의 실제 API 호출/정규화 로직
- `app/public/shared/synthetic.mjs`의 fixture 재생 로직
- `app/public/data/records.json`의 실제 원본 기록
- 기존 T04 fixture 파일과 T04 검사 기대값
- 그래프를 위해 API를 다시 호출하거나 저장값을 재계산하는 방식
